/** Automatically generated file. DO NOT MODIFY */
package com.example.listview1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}