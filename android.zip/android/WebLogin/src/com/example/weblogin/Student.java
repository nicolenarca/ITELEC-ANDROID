package com.example.weblogin;

public class Student {
	
	String idno, familyname, givenname, campus, course, year;

	public Student(String idno, String familyname, String givenname, String campus,
			String course, String year) {
		super();
		this.idno = idno;
		this.familyname = familyname;
		this.givenname = givenname;
		this.campus = campus;
		this.course = course;
		this.year = year;
	}

	public String getIdno() {
		return idno;
	}

	public void setIdno(String idno) {
		this.idno = idno;
	}

	public String getFname() {
		return familyname;
	}

	public void setFname(String familyname) {
		this.familyname = familyname;
	}

	public String getGname() {
		return givenname;
	}

	public void setGname(String givenname) {
		this.givenname = givenname;
	}

	public String getCampus() {
		return campus;
	}

	public void setCampus(String campus) {
		this.campus = campus;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
	
	

}
