package com.example.crudlist;

import android.app.Activity;

public class updateActivity extends Activity {
 
	EditText txtName;
	Button btnSave,btnCancel;
	
	@Override
	protected void onCreate(Bundle savedInstaceState){
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.updateitem);
	}
}
