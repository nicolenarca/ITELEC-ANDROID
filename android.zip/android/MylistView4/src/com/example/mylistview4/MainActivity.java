package com.example.mylistview4;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity implements OnItemClickListener {
	
	ListView lv;
	EditText search;
	ItemAdapter adapter;
	ArrayList<Student> list = new ArrayList<Student>();
	ArrayList<Student> list2 = new ArrayList<Student>();
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		
		lv = (ListView) this.findViewById(R.id.listView1);
		search = (EditText) this.findViewById(R.id.editText1);
		
		adapter = new ItemAdapter(this,list2);
		lv.setAdapter(adapter);
		
		list.add(new Student(R.drawable.img1, "Alpha Bravo", "BSIT-2"));
		list.add(new Student(R.drawable.img10, "Charlie Delta", "BSCS-1"));
		list.add(new Student(R.drawable.img11, "Delta Echo", "HRM-3"));
		list.add(new Student(R.drawable.img12, "Bravo Echo", "BEED-4"));
		list.add(new Student(R.drawable.img13, "Echo Foxtrot", "BSED-1"));
		list.add(new Student(R.drawable.img2, "Foxtrot Golf", "BSOA-3"));
		list.add(new Student(R.drawable.img3, "Golf Hotel", "BEED-3"));
		list.add(new Student(R.drawable.img4, "Hotel India", "BSCREAM-1"));
		
		lv.setOnItemClickListener(this);
	
		
		search.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
				list2.clear();
				
				Pattern p = Pattern.compile(arg0.toString());
				
				for(int i=0; i<list.size(); i++){
					
					Matcher m = p.matcher(list.get(i).getFullname());
				
					if(m.find())
					{
						list2.add(new Student(list.get(i).getImage(), list.get(i).getFullname(), list.get(i).getCourse()));
					}
					adapter.notifyDataSetChanged();
				}
				
			}
			
		});
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
		ImageView iv = new ImageView(this);
				iv.setImageResource(list.get(arg2).getImage());
	  TextView myname=new TextView(this);
				myname.setText(list.get(arg2).getFullname());
	  TextView mycourse=new TextView(this);
				mycourse.setText(list.get(arg2).getCourse());
				
				
				LinearLayout mainLayout=new LinearLayout(this);	
				mainLayout.setOrientation(LinearLayout.HORIZONTAL);
				mainLayout.addView(iv);
				
		LinearLayout subLayout=new LinearLayout(this);
			subLayout.setOrientation(LinearLayout.VERTICAL);
			subLayout.addView(myname);
			subLayout.addView(mycourse);
			
			mainLayout.addView(subLayout);
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(list.get(arg2).getFullname())
			.setView(mainLayout)
			.setNeutralButton("OKEY", null);
		AlertDialog dialog = builder.create();
		dialog.show();
	
		
	}

}
