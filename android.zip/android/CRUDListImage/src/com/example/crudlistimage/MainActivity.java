package com.example.crudlistimage;

import java.util.ArrayList;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;

public class MainActivity extends Activity {

	ListView lv;
	ArrayList<Person> list=new ArrayList<Person>();
	ItemAdapter adapter;
	PersonDatabase db;
	Uri uri;
	String name;
	AdapterView.AdapterContextMenuInfo info;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    
        db=new PersonDatabase(this); 
        if(db.getAllPerson() != null){ 
        	list=db.getAllPerson();
        }
        
        this.lv=(ListView) this.findViewById(R.id.listView1);
        this.adapter = new ItemAdapter(this,list);
        this.lv.setAdapter(adapter);
        
       this.lv.setAdapter(adapter);
        this.registerForContextMenu(lv);
        
    }



	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent intent = new Intent(this,UpdatePersson.class);
		this.startActivityForResult(intent,0);
		return super.onOptionsItemSelected(item);
	}

    @Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		this.getMenuInflater().inflate(R.menu.contextmenu, menu);
		super.onCreateContextMenu(menu, v, menuInfo);
		info = (AdapterContextMenuInfo) menuInfo;
		menu.setHeaderTitle(list.get(info.position).getName());
    }



	@Override
	public boolean onContextItemSelected(MenuItem item) {
	
		switch(item.getItemId()){
		case R.id.update:
		Uri image = list.get(info.position).getImageUri();
		String name = list.get(info.position).getName();
		
		Intent intent = new Intent(this, UpdatePersson.class);
		intent.putExtra("image", image);
		intent.putExtra("name", name);		
		this.startActivityForResult(intent,1);
		
		break;
		
		case R.id.delete:
			Uri img = (list.get(info.position).getImageUri());
			String nm= (list.get(info.position).getName());
			
			list.remove(info.position);
			db.deletePerson(nm, img);
			this.adapter.notifyDataSetChanged();
		}
		
		return super.onContextItemSelected(item); 
	}



	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == Activity.RESULT_OK){
			
			Bundle b=data.getExtras();
			name = b.getString("name");
			uri=b.getParcelable("image");
			String exname=b.getString("exname");
			
			if(requestCode == 0)
			{
				list.add(new Person(uri, name));
				db.addPerson(uri, name);
			}
			
			if(requestCode == 1)
			{
				list.set(info.position, new Person(uri, name));
				db.updatePerson(uri, name, exname);
			}
			
		}
		adapter.notifyDataSetChanged();
	}
    
    
	public void onClick(DialogInterface arg0, int arg1) {
		

		switch(arg1)
		{
		case DialogInterface.BUTTON_POSITIVE:
			

			String nm = list.get(info.position).getName();
			Uri img = list.get(info.position).getImageUri();
			
			list.remove(info.position);
			db.deletePerson(nm,img);
			adapter.notifyDataSetChanged();
			break;
		case DialogInterface.BUTTON_NEGATIVE: arg0.dismiss();
		}
		
	}
}
