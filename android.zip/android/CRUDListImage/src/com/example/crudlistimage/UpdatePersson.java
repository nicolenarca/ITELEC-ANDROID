package com.example.crudlistimage;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class UpdatePersson extends Activity implements OnClickListener {

	
	ImageView iv;
	EditText txtName;
	Button btnSave,btnCancel;
	Uri uri;
	private String exname;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		this.setContentView(R.layout.updateperson_layout);
		
		this.iv=(ImageView) this.findViewById(R.id.imageView1);
		this.txtName=(EditText) this.findViewById(R.id.editText1);
		this.btnSave=(Button) this.findViewById(R.id.button1);
		this.btnCancel=(Button) this.findViewById(R.id.button2);
		
		Bundle b = this.getIntent().getExtras();
		
		if(b != null)
		{
			Uri uri = b.getParcelable("image");
			exname = b.getString("name");
			
			this.iv.setImageURI(uri);
			this.txtName.setText(exname);
		}

		
		this.iv.setOnClickListener(this);
		this.btnSave.setOnClickListener(this);
		this.btnCancel.setOnClickListener(this);
		
		
	}

	@Override
	public void onClick(View arg0) {
	

		switch(arg0.getId()){
		case R.id.imageView1://create
			Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		this.startActivityForResult(intent,100);
		break;
		case R.id.button1://save
			
			String name= this.txtName.getText().toString();
			if(name.equals("") || uri==null){
				Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
			}
			else{
			 Intent btnSave=new Intent();
			 btnSave.putExtra("image",uri);
			 btnSave.putExtra("name",name);
			 btnSave.putExtra("exname", exname);
			this.setResult(Activity.RESULT_OK, btnSave);
			}	
						
		case R.id.button2://cancel
			this.finish();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
	
		uri=data.getData();
		this.iv.setImageURI(uri);
	}
	
	

}
