package com.example.mytab;

import java.util.ArrayList;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NameListActivity extends Activity {
	
	ListView lv;
	ArrayList<String> list = new ArrayList<String>();
	ArrayAdapter<String> adapter;
	Database db;
	
	//LOCATIONLIST
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.name);
		
		db = new Database(this);
		
		if(db.getAllLocation() != null)
		{
			list = db.getAllLocation();
		}
		
		
		adapter = new  ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
		this.lv=(ListView) this.findViewById(R.id.listView1);
		this.lv.setAdapter(adapter);

	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		Bundle b = data.getExtras();
		if(b != null)
		{
			String lng = b.getString("lng");
			String lat = b.getString("lat");
			list.add("Longitude: "+lng+"\nLatitude: "+lat);
			adapter.notifyDataSetChanged();
		}
	}
}
