package com.example.mytab;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class MainActivity extends TabActivity {
	
	TabHost tabhost;
	String lng="", lat="";
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        
        tabhost=this.getTabHost();
        
        Intent addIntent=new Intent(this,AddNameActivity.class);
        Intent listIntent=new Intent(this,NameListActivity.class);
        Intent autobio=new Intent(this, Autobio.class);
    
        Bundle b = this.getIntent().getExtras();
		if(b != null)
		{
			 lng = b.getString("lng");
			 lat = b.getString("lat");
			 listIntent.putExtra("lng", lng);
		     listIntent.putExtra("lat", lat);
		}

        
        Drawable listicon= this.getResources().getDrawable(R.drawable.mylocation);
        Drawable addicon= this.getResources().getDrawable(R.drawable.add);
        Drawable me= this.getResources().getDrawable(R.drawable.info);
        

        
        TabSpec namelist=tabhost.newTabSpec("listicon");
        namelist.setIndicator("", listicon);
        namelist.setContent(listIntent);
        
        TabSpec addlist=tabhost.newTabSpec("addicon");
        addlist.setIndicator("",addicon);
        addlist.setContent(addIntent);

        
        TabSpec autobiog =tabhost.newTabSpec("me");
		autobiog.setIndicator("", me);
		autobiog.setContent(autobio);
        
        tabhost.addTab(namelist);
        tabhost.addTab(addlist);
        tabhost.addTab(autobiog);
              
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
