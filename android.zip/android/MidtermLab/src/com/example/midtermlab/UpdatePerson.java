package com.example.midtermlab;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class UpdatePerson extends Activity {

	ImageView iv;
	EditText txtName;
	Button btnOk,btnCancel;
	 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		this.setContentView(R.layout.updateperson_layout);
		this.iv=(ImageView) this.findViewById(R.id.imageView1);
		this.txtName=(EditText) this.findViewById(R.id.editText1);
		this.btnOk=(Button) this.findViewById(R.id.button1);
		this.btnCancel=(Button)this.findViewById(R.id.button2);
		
	}

}
