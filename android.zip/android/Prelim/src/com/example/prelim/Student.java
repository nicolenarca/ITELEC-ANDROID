package com.example.prelim;

public class Student{

    private String studentName;
    private String course;


public Student(String studentName, String course) {
    super();
    this.studentName = studentName;
    this.course = course;
}




}