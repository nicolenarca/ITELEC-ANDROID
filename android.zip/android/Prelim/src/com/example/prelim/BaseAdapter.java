package com.example.prelim;

public interface BaseAdapter {

}
