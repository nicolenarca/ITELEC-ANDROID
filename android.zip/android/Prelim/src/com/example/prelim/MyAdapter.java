package com.example.prelim;

import java.util.ArrayList;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

public class MyAdapter implements BaseAdapter, ListAdapter  {

    Context context;
    ArrayList<Student> list;
    LayoutInflater inflater;
    
    public MyAdapter(){
        super();
        this.context=context;
        this.list=list;
        this.inflater=LayoutInflater.from(context);
    }
    
    public MyAdapter(MainActivity mainActivity, ArrayList<Student> list2) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
	    public int getCount(){
	        return 0;
	        return list.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
	    return list.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
	    return arg0;
	}

	@Override
	public int getItemViewType(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int arg0, View arg1, ViewGroup arg2) {
		// TODO Auto-generated method stub
	       StudentHandler handler=null;

	        if (arg1==null){
	            arg1=inflater.inflate(R.layout.itemlayout, null);
	            handler=new StudentHandler();
	            handler.name=(TextView)arg1.findViewById(R.id.editText1);
	            handler.course=(TextView)arg1.findViewById(R.id.editText2);
	            arg1.setTag(handler);
	        }
	        else handler=(StudentHandler)arg1.getTag();

	        handler.name.setText(list.get(arg0).getStudentName());
	        handler.course.setText(list.get(arg0).getCourse());
	        return arg1;
	}
	
    static class StudentHandler{
        TextView name;
        TextView course;

    }
	@Override
	public int getViewTypeCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void registerDataSetObserver(DataSetObserver arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void unregisterDataSetObserver(DataSetObserver arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean areAllItemsEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled(int arg0) {
		// TODO Auto-generated method stub
		return false;
	}



}
