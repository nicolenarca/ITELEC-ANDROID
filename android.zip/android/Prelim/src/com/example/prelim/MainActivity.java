package com.example.prelim;

import java.util.ArrayList;

import com.example.listview2.R;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

 public class MainActivity extends Activity implements OnClickListener {

    ListView lv;
	EditText name,course;
	Button add;
    ArrayList<Student> list=new ArrayList<Student>();
    MyAdapter adapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        

        this.name=(EditText)this.findViewById(R.id.editText1);
        this.course=(EditText)this.findViewById(R.id.editText2);
    
        this.add=(Button)this.findViewById(R.id.button1);
        this.add.setOnClickListener(this);
        
        lv=(ListView)this.findViewById(R.id.listView1);
        list.add(new Student(R.drawable.EditText1));
        list.add(new Student(R.drawable.EditText2));
        
        adapter=new MyAdapter(this,list);
        this.lv.setAdapter(adapter);

        
        
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}
    
}
