<?php
//retrieve the data from the file 'student.txt'


	$filename='student.txt';
	
	if(file_exists($filename)){
		
		//read the content of the file
		$file=file($filename);		//the function will return an array of records, put them on the variable $file
		
		echo '<table border=1 width=100%>';
			echo '<tr>';
				echo '<th>IDNO</th>';
				echo '<th>FAMILYNAME</th>';
				echo '<th>GIVENNAME</th>';
				echo '<th>COURSE</th>';
				echo '<th>YEAR</th>';				
				echo '<th>CAMPUS</th>';				
			echo '</tr>';
			foreach($file as $record){
				//extract the records into fields
				$field=explode(",",$record);		//return an array of delimited strings
				//put each field as data on the table
				echo '<tr>';
				foreach($field as $f){
					echo '<td>'.$f.'</td>';
				}				
				echo '</tr>';
			}
		echo '</table>';
	}
	else	echo 'File is Empty';
?>