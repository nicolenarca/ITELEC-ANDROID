<?php

$host="localhost";
$username="root";
$password="";
$db="ictcongress";



mysql_connect($host, $username, $password);
mysql_select_db($db);

$query="SELECT * FROM tbl_student";

$result = mysql_query($query);

if(mysql_num_rows($result) > 0){
	while($record = mysql_fetch_assoc($result)){
			$flag[] = $record;
	}
	print(json_encode($flag));
}




mysql_close();
?>