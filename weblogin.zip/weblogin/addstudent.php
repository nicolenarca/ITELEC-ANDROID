<?php

$host="localhost";
$username="root";
$password="";
$db="ictcongress";

mysql_connect($host, $username, $password);
mysql_select_db($db);

if(isset($_GET['idno'])){
$idno = $_GET['idno'];
$familyname = $_GET['familyname'];
$givenname = $_GET['givenname'];
$course = $_GET['course'];
$yearlevel = $_GET['yearlevel'];
$campus = $_GET['campus'];

$query="INSERT INTO tbl_student VALUES('$idno', '$familyname', '$givenname', '$course', '$yearlevel', '$campus')";
mysql_query($query);

echo'New Student Added!';
}
else
	echo'Failed to add student';

mysql_close();


?>